This folder only exists so an old GitHub workflow that uses "working-directory: ./android" still works.
The real Sociax project is the folder above this one. You can delete the old workflow file later;
the right one is .github/workflows/build-apk.yml.
